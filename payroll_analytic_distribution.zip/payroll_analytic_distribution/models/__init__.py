# -*- coding: utf-8 -*-

from . import salary_structure
from . import hr_work_entry
from . import hr_payslip
from . import salary_rule